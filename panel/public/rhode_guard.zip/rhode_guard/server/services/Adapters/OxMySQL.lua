--[[
    RHODE GUARD ULTIMATE — Adapter oxmysql (mode autonome)
    Utilisé quand le panel web est absent/injoignable: les incidents sont stockés
    localement via oxmysql (exports, requêtes 100% paramétrées — migrations/001_init.sql).

    File d'attente bornée + écritures asynchrones: une panne MySQL ne bloque
    JAMAIS le tick de jeu; les incidents critiques sont prioritaires.
]]

RHODE = RHODE or {}
RHODE.Adapters = RHODE.Adapters or {}
RHODE.Adapters.OxMySQL = RHODE.OxMySQL or {}
RHODE.OxMySQL = RHODE.Adapters.OxMySQL

local available = false
local pendingWrites = 0

CreateThread(function()
    for _ = 1, 30 do
        if GetResourceState('oxmysql') == 'started' then
            available = true
            break
        end
        Wait(1000)
    end
    if available then
        -- auto-migration si la table manque (idempotent: CREATE TABLE IF NOT EXISTS)
        exports.oxmysql:execute([[
            CREATE TABLE IF NOT EXISTS rhode_incidents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                incident_id TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                license TEXT NOT NULL,
                player_name TEXT,
                module TEXT NOT NULL,
                type TEXT NOT NULL,
                severity TEXT NOT NULL,
                confidence INTEGER NOT NULL DEFAULT 85,
                source TEXT NOT NULL DEFAULT 'SERVEUR',
                detector_version TEXT,
                mode TEXT,
                case_ref TEXT,
                facts TEXT,
                context TEXT,
                integrity TEXT
            )
        ]], nil, function()
            print('^2[RHODE GUARD] mode autonome oxmysql prêt (table rhode_incidents vérifiée)^0')
        end)
    else
        print('[RHODE GUARD] oxmysql absent — stockage local désactivé (panel requis)')
    end
end)

function RHODE.OxMySQL.Available()
    return available
end

--- Stocke un incident localement (asynchrone, requêtes paramétrées uniquement).
function RHODE.OxMySQL.StoreIncident(evidence)
    if not available then return false end
    if pendingWrites > 100 then
        -- backpressure: on ne laisse pas s'accumuler
        return false
    end
    pendingWrites = pendingWrites + 1
    exports.oxmysql:execute(
        'INSERT INTO rhode_incidents (incident_id, created_at, license, player_name, module, type, severity, confidence, source, detector_version, mode, case_ref, facts, context, integrity) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        {
            evidence.incidentId,
            evidence.ts,
            evidence.license,
            evidence.name,
            evidence.module,
            evidence.type,
            evidence.severity,
            evidence.confidence,
            evidence.source,
            evidence.detectorVersion,
            evidence.mode,
            evidence.caseRef,
            json.encode(evidence.facts or {}),
            json.encode(evidence.context or {}),
            evidence.integrity,
        },
        function()
            pendingWrites = pendingWrites - 1
        end
    )
    return true
end

--- Derniers incidents locaux (lecture, utile en mode autonome).
function RHODE.OxMySQL.RecentIncidents(limit, cb)
    if not available then
        if cb then cb({}) end
        return
    end
    limit = math.min(math.max(tonumber(limit) or 20, 1), 100)
    exports.oxmysql:execute(
        'SELECT * FROM rhode_incidents ORDER BY created_at DESC LIMIT ?',
        { limit },
        function(rows)
            if cb then cb(rows or {}) end
        end
    )
end

--[[ ============ ÉCONOMIE v2.1: journal d'opérations + idempotence (§18/§27) ============
    Tables créées par migrations/002_idempotency.sql (et à la volée ci-dessous,
    idempotent). Écritures ASYNCHRONES uniquement — jamais dans le chemin critique. ]]

function RHODE.OxMySQL.EnsureEconomyTables()
    if not available then return end
    exports.oxmysql:execute([[
        CREATE TABLE IF NOT EXISTS rhode_operations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at INTEGER NOT NULL,
            license TEXT NOT NULL,
            op_type TEXT NOT NULL,
            state TEXT NOT NULL,
            idem_key_digest TEXT,
            payload_digest TEXT,
            amount REAL,
            result_code TEXT
        )
    ]], nil, function()
        exports.oxmysql:execute([[
            CREATE TABLE IF NOT EXISTS rhode_idempotency (
                scope TEXT NOT NULL,
                operation_key_digest TEXT NOT NULL,
                payload_digest TEXT NOT NULL,
                status TEXT NOT NULL,
                result_json TEXT,
                expires_at INTEGER NOT NULL,
                PRIMARY KEY (scope, operation_key_digest)
            )
        ]], nil, function()
            print('^2[RHODE GUARD] économie: tables idempotence/journal vérifiées^0')
        end)
    end)
end

--- Journalise une opération (asynchrone, best-effort, requêtes paramétrées).
function RHODE.OxMySQL.StoreOperation(op)
    if not available then return false end
    exports.oxmysql:execute(
        'INSERT INTO rhode_operations (created_at, license, op_type, state, idem_key_digest, payload_digest, amount, result_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        {
            os.time(), op.license or '', op.opType or '', op.state or '',
            op.idemKey or '', op.payloadDigest or '', op.amount or nil, op.resultCode or nil,
        }
    )
    -- persiste l'idempotence pour la reprise après redémarrage
    if op.idemKey and op.idemKey ~= '' then
        exports.oxmysql:execute(
            'INSERT INTO rhode_idempotency (scope, operation_key_digest, payload_digest, status, result_json, expires_at) VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT(scope, operation_key_digest) DO UPDATE SET status = ?, result_json = ?, expires_at = ?',
            {
                'economy', op.idemKey, op.payloadDigest or '', op.state,
                op.result and json.encode(op.result) or nil,
                os.time() + 600,
                op.state, op.result and json.encode(op.result) or nil, os.time() + 600,
            }
        )
    end
    return true
end

--- Recharge les clés d'idempotence actives (appelé au démarrage de la ressource).
function RHODE.OxMySQL.LoadActiveIdempotency(cb)
    if not available then
        if cb then cb({}) end
        return
    end
    exports.oxmysql:execute(
        'SELECT operation_key_digest, payload_digest, status, result_json, expires_at FROM rhode_idempotency WHERE expires_at > ?',
        { os.time() },
        function(rows)
            if cb then cb(rows or {}) end
        end
    )
end
