# RHODE GUARD ULTIMATE — Guide du panel & matrice de permissions

Le panel est en français, responsive (desktop/tablette/mobile), style terminal.
Navigation clavier complète; chaque action sensible est auditée.

## Vues

| Vue | Rôle | Points clés |
|---|---|---|
| **Dashboard** | tous | bandeau MODE, **bandeau santé par serveur** (PRET/DÉGRADÉ/ARRÊT, file, fraîcheur), stats live, graphique 24 h, flux temps réel, top risque |
| **Dossiers** | tous (consultation) | file de revue avec **machine à états motivée** (§28): OUVERT → EN REVUE → ESCALADÉ → CLÔTURÉ (faux positif/sanction) ou REJETÉ; réouverture motivée; **historique de transitions**; assignation; notes; appel |
| **Joueurs** | tous | recherche, filtre en ligne, fiche: risque, identifiants (repliés), dossiers, détections, bans |
| **Détections** | tous | filtres type/sévérité/**source** (client/serveur/croisée), détail JSON au clic, marquage faux positif |
| **Sanctions** | selon rôle | bans actifs/expirés/révoqués, création (bornée par rôle), levée motivée, badge APPEL |
| **Réglages** | lecture: tous · écriture: ADMIN+ | mode global, kill-switch + seuils par détecteur, auto-sanction, rétention — confirmation pour ENFORCE; **workflow de révision** (brouillon → validation → approbation séparée → activation confirmée, diff, rollback) ou urgence tracée |
| **Staff** | OWNER | comptes, rôles, activation |
| **Audit** | ADMIN+ | journal immuable: connexions, échecs, sanctions, changements de réglages, actions dossiers |
| **Webhooks** | ADMIN+ | Discord: `detection.high`, `ban`, `unban`, `case.open`, test d'envoi |
| **Serveurs** | OWNER | clé API par serveur (régénérable), heartbeats |
| **Installation** | tous | guide + architecture + exports + note de sécurité |

## Matrice de permissions (RBAC, refus par défaut, vérifiée CÔTÉ SERVEUR)

Mapping rôles implémentés ↔ rôles métier de la spécification (§20):
OWNER=Administrateur · ADMIN=Ingénieur sécurité/Admin délégué · MODERATOR=Modérateur/Analyste · SUPPORT=Observateur/Analyse lecture · **AUDITOR=Auditeur**.

| Permission | OWNER | ADMIN | MODERATOR | SUPPORT | AUDITOR |
|---|:-:|:-:|:-:|:-:|:-:|
| Consulter (dashboard, détections, bans, dossiers) | ✓ | ✓ | ✓ | ✓ | ✓ |
| Consulter les joueurs (identifiants) | ✓ | ✓ | ✓ | ✓ | — |
| Marquer faux positif | ✓ | ✓ | ✓ | — | — |
| Gérer les dossiers (transitions motivées, assignation, appel) | ✓ | ✓ | ✓ | — | — |
| Notes d'enquête | ✓ | ✓ | ✓ | — | — |
| Ban temporaire | ✓ ≤ 1 an | ✓ ≤ 90 j | ✓ ≤ **7 j** | — | — |
| Ban permanent | ✓ | ✓ | — | — | — |
| Blacklist HWID | ✓ | ✓ | — | — | — |
| Lever un ban | ✓ | ✓ | — | — | — |
| Voir l'audit | ✓ | ✓ | — | — | ✓ |
| Gérer webhooks / réglages | ✓ | ✓ | — | — | — |
| Gérer staff / serveurs | ✓ | — | — | — | — |

Rôles entièrement configurables (§20 « jamais codés en dur comme unique source »):
la matrice vit dans `src/lib/permissions.ts` côté serveur — l'UI ne décide jamais.

## Comptes de démonstration (À SUPPRIMER en production)

| Compte | Mot de passe | Rôle |
|---|---|---|
| owner | owner123 | PROPRIÉTAIRE — accès total |
| admin | admin123 | ADMIN — bans, réglages, webhooks, audit |
| modo | modo123 | MODÉRATEUR — bans temp 7 j max, dossiers |
| support | support123 | SUPPORT — lecture seule |
| auditor | auditor123 | AUDITEUR — journal d'audit, aucune mutation, aucun identifiant joueur |

Sécurité du panel: sessions 12 h (cookie httpOnly), **rate-limit login** (8 essais /
10 min / IP), messages d'erreur génériques (pas de divulgation de comptes),
journalisation de TOUTES les tentatives (y compris échouées).

## Bonnes pratiques d'enquête

1. Ouvrir le **dossier** (pas la détection isolée): chronologie + notes.
2. Vérifier la **source**: `serveur`/`croisée` = forte confiance; `client` = à
   corroborer (le client peut mentir).
3. Croiser le contexte ESX (métier, soldes) et le ping (lag ≠ cheat).
4. Conclure: FAUX POSITIF (le score de risque en tient compte), SANCTION
   (motivée, durée selon politique), ou REJETÉ (pas assez de preuves).
5. Les appels passent par le statut d'appel du dossier/ban — jamais de
   modification silencieuse.
