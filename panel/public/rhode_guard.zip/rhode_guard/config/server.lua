--[[
    RHODE GUARD ULTIMATE — Configuration serveur
    Les SECRETS (clé API) vont dans ce fichier, absent des dépôts publics.
    Ne mets JAMAIS de clé admin dans une ressource client — la clé ci-dessous ne
    circule qu'entre FXServer et le panel (en-tête X-API-Key, HTTPS recommandé).
]]

Config = Config or {}

-- ============ PANEL WEB ============
-- URL publique du panel avec suffixe /api/v1 — ex: "https://panel.mondomaine.com/api/v1"
-- Laisse vide ('') pour le MODE AUTONOME (stockage local oxmysql, sans panel).
Config.PanelURL = 'http://VOTRE-PANEL:3000/api/v1'

-- Clé API générée dans le panel (SERVEURS → ton serveur → clé).
Config.ApiKey = 'REMPLACER-PAR-LA-CLE-API'

-- ============ CONNEXION ============
Config.BanCheckTimeout = 5000   -- ms max pour vérifier un ban à la connexion
Config.HeartbeatInterval = 60   -- s entre chaque heartbeat vers le panel
Config.ConfigSyncInterval = 60  -- s entre chaque synchronisation des réglages (kill-switch live)
Config.PanelHealthTimeout = 900 -- s sans réponse panel → considéré injoignable (file locale)

-- ============ LOGS ============
Config.Debug = false -- logs détaillés côté serveur (développement uniquement)

-- ============ NOTE DE SÉCURITÉ ============
-- En production: serve le panel en HTTPS devant (reverse proxy), restreins l'accès
-- à l'API v1 par pare-feu si possible, et fais tourner la clé API périodiquement
-- depuis le panel (SERVEURS → régénérer).
